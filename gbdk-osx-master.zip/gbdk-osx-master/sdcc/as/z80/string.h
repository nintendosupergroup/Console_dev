/* STRING.H */
/* DECUC C */

extern	char *	strcat();
extern	char *	strchr();
extern	int	strcmp();
extern	char *	strcpy();
extern	int	streq();
extern	int	strlen();
extern	char *	strncat();
extern	int	strncmp();
extern	char *	strncpy();
extern	int	strneq();
extern	char *	strrchr();

