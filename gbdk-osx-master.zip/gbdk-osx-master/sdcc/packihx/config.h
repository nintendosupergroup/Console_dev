/* config.h.  Generated automatically by configure.  */
#ifndef PACKIHX_HEADER
#define PACKIHX_HEADER

#define TYPE_BYTE char
#define TYPE_WORD short
#define TYPE_UBYTE unsigned TYPE_BYTE
#define TYPE_UWORD unsigned TYPE_WORD

typedef TYPE_UBYTE Uint8;
typedef TYPE_UWORD Uint16;

#endif
