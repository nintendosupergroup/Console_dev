#define DS1621_ID 0x90

extern float ReadDS1621(char address);
