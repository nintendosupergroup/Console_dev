/** Silly types.h
    Z80 specific hack
*/

#ifndef TYPES_INCLUDE
#define TYPES_INCLUDE

typedef unsigned char BYTE;
typedef unsigned WORD;

#endif
