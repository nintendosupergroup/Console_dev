/* avr.src/instcl.h */

  virtual int nop(t_mem code);
  virtual int sleep(t_mem code);
  virtual int wdr(t_mem code);
  virtual int ser_Rd(t_mem code);

/* End of avr.src/instcl.h */
