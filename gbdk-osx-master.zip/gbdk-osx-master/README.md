# GBDK-OSX

Patched **GBDK** 2.96a for the latest compilers on **OS X**.

Original site:

  * http://sourceforge.net/projects/gbdk
  
  
# Highlights

The **GameBoy Developer's Kit** (**GBDK**), is a set of tools that enable to develop programs for the Nintendo GameBoy system, either in C or in assembly. GBDK includes a set of libraries for the most common requirements and generates image files for use with a real GameBoy or with an emulator like VGB or no$gmb.