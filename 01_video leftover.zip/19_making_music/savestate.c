
movegamecharacter(&bug, bug.x, bug.y);
        if(bug.y) >=144{
            bug.y = 0;
            movegamecharacter(&bug, bug.x, bug.y);
        }
