#include <gb.gb.h>
void init_movement(){


    if(joypad() & J_DOWN){
         set_sprite_tile(1,9);
    set_sprite_tile(2,10);
    set_sprite_tile(3,11);
    set_sprite_tile(4,12);
    scroll_sprite(1,0,2);
    scroll_sprite(2,0,2);
    scroll_sprite(3,0,2);
    scroll_sprite(4,0,2);
delay(180);
     set_sprite_tile(1,5);
    set_sprite_tile(2,6);
    set_sprite_tile(3,7);
    set_sprite_tile(4,8);
    scroll_sprite(1,0,2);
    scroll_sprite(2,0,2);
    scroll_sprite(3,0,2);
    scroll_sprite(4,0,2);
    delay(180);
    }

    {
          if(joypad() & J_RIGHT){
    set_sprite_tile(1,17);
    set_sprite_tile(2,18);
    set_sprite_tile(3,19);
    set_sprite_tile(4,20);
    scroll_sprite(1,2,0);
    scroll_sprite(2,2,0);
    scroll_sprite(3,2,0);
    scroll_sprite(4,2,0);
delay(180);
     set_sprite_tile(1,13);
    set_sprite_tile(2,14);
    set_sprite_tile(3,15);
    set_sprite_tile(4,16);
    scroll_sprite(1,2,0);
    scroll_sprite(2,2,0);
    scroll_sprite(3,2,0);
    scroll_sprite(4,2,0);
    delay(180);
    }
    }
    {
          if(joypad() & J_UP){
    set_sprite_tile(1,25);
    set_sprite_tile(2,26);
    set_sprite_tile(3,27);
    set_sprite_tile(4,28);
    scroll_sprite(1,0,-2);
    scroll_sprite(2,0,-2);
    scroll_sprite(3,0,-2);
    scroll_sprite(4,0,-2);
delay(180);
     set_sprite_tile(1,21);
    set_sprite_tile(2,22);
    set_sprite_tile(3,23);
    set_sprite_tile(4,24);
    scroll_sprite(1,0,-2);
    scroll_sprite(2,0,-2);
    scroll_sprite(3,0,-2);
    scroll_sprite(4,0,-2);
    delay(180);
    }
    }
    {
          if(joypad() & J_LEFT){
    set_sprite_tile(1,33);
    set_sprite_tile(2,34);
    set_sprite_tile(3,35);
    set_sprite_tile(4,36);
    scroll_sprite(1,-2,0);
    scroll_sprite(2,-2,0);
    scroll_sprite(3,-2,0);
    scroll_sprite(4,-2,0);
delay(180);
     set_sprite_tile(1,29);
    set_sprite_tile(2,30);
    set_sprite_tile(3,31);
    set_sprite_tile(4,32);
    scroll_sprite(1,-2,0);
    scroll_sprite(2,-2,0);
    scroll_sprite(3,-2,0);
    scroll_sprite(4,-2,0);
    delay(180);
    }
    }
}
