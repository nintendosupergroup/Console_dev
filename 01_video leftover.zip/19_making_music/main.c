
#include <gb/gb.h>
#include "gbt_player.h"
#include "link.c"//this is Link's Animation sprites
#include "face.c"
UINT8 i;
short link_x = 91;
short link_y = 91;
short link_r = 16;
short face_r = 8;
short face_x_y = 75;

extern const unsigned char * song_Data[];

void performantdelay(UINT8 numloops){
    UINT8 i;
    for(i = 0; i < numloops; i++){
        wait_vbl_done();
    }
}
void fadeout(){
	for(i=0;i<4;i++){
		switch(i){
			case 0:
				BGP_REG = 0xE4;
				break;
			case 1:
				BGP_REG = 0xF9;
				break;
			case 2:
				BGP_REG = 0xFE;
				break;
			case 3:
				BGP_REG = 0xFF;
				break;
		}
		performantdelay(10);
	}
}

void fadein(){
	for(i=0;i<3;i++){
		switch(i){
			case 0:
				BGP_REG = 0xFE;
				break;
			case 1:
				BGP_REG = 0xF9;
				break;
			case 2:
				BGP_REG = 0xE4;
				break;
		}
		performantdelay(10);
	}
}
void init_movement(){

          if(joypad() & J_UP){
link_y -= 2;

    set_sprite_tile(1,30);
    set_sprite_tile(2,31);
    set_sprite_tile(3,32);
    set_sprite_tile(4,33);
    scroll_sprite(1,0,-1);
    scroll_sprite(2,0,-1);
    scroll_sprite(3,0,-1);
    scroll_sprite(4,0,-1);

     set_sprite_tile(1,26);
    set_sprite_tile(2,27);
    set_sprite_tile(3,28);
    set_sprite_tile(4,29);
    scroll_sprite(1,0,-1);
    scroll_sprite(2,0,-1);
    scroll_sprite(3,0,-1);
    scroll_sprite(4,0,-1);

    }
    if(joypad() & J_LEFT){
if(link_x != face_x_y + 6){

        link_x -= 2;
    set_sprite_tile(1,38);
    set_sprite_tile(2,39);
    set_sprite_tile(3,40);
    set_sprite_tile(4,41);
    scroll_sprite(1,-1,0);
    scroll_sprite(2,-1,0);
    scroll_sprite(3,-1,0);
    scroll_sprite(4,-1,0);

     set_sprite_tile(1,34);
    set_sprite_tile(2,35);
    set_sprite_tile(3,36);
    set_sprite_tile(4,37);
    scroll_sprite(1,-1,0);
    scroll_sprite(2,-1,0);
    scroll_sprite(3,-1,0);
    scroll_sprite(4,-1,0);
}

    }
    if(joypad() & J_DOWN){
            link_y += 2;
         set_sprite_tile(1,14);
    set_sprite_tile(2,15);
    set_sprite_tile(3,16);
    set_sprite_tile(4,17);
    scroll_sprite(1,0,1);
    scroll_sprite(2,0,1);
    scroll_sprite(3,0,1);
    scroll_sprite(4,0,1);
     set_sprite_tile(1,10);
    set_sprite_tile(2,11);
    set_sprite_tile(3,12);
    set_sprite_tile(4,13);
    scroll_sprite(1,0,1);
    scroll_sprite(2,0,1);
    scroll_sprite(3,0,1);
    scroll_sprite(4,0,1);


    } {
          if(joypad() & J_RIGHT){
if (link_y <= face_x_y){


link_x += 2;
    set_sprite_tile(1,22);
    set_sprite_tile(2,23);
    set_sprite_tile(3,24);
    set_sprite_tile(4,25);
    scroll_sprite(1,1,0);
    scroll_sprite(2,1,0);
    scroll_sprite(3,1,0);
    scroll_sprite(4,1,0);

     set_sprite_tile(1,18);
    set_sprite_tile(2,19);
    set_sprite_tile(3,20);
    set_sprite_tile(4,21);
    scroll_sprite(1,1,0);
    scroll_sprite(2,1,0);
    scroll_sprite(3,1,0);
    scroll_sprite(4,1,0);

          }}}
    }


void init_faceanim(){
/*this statement means that it is a enclosed program
that in this case, can be reused with the command
"init faceanim()"*/
set_sprite_data(10, 32,link);
set_sprite_data(0,5,face);

set_sprite_tile(0,0);

move_sprite(0, face_x_y,face_x_y);

    set_sprite_tile(1,10);
        set_sprite_tile(2,11);
    set_sprite_tile(3,12);
    set_sprite_tile(4,13);
move_sprite(1, link_x, link_y);
    move_sprite(2,link_x + 8 ,link_y);
    move_sprite(3,link_x,link_y + 8);
    move_sprite(4,link_x + 8 ,link_y + 8);


}

void main()
{
SPRITES_8x8;

SHOW_SPRITES;


fadeout();
disable_interrupts();
    gbt_play(song_Data, 2, 50);
    gbt_loop(1);
     set_interrupts(VBL_IFLAG);
    enable_interrupts();
init_faceanim();
fadein();


    while (1)
    {
        wait_vbl_done();
        init_movement();
        gbt_update(); // This will change to ROM bank 1.

    }

}
