#include <gb/gb.h>// always include this in gameboy roms
#include "link.c"//this is Link's Animation sprites
#include "face.c"//this was from a early project that is now a wall
short link_x = 91;
short link_y = 75;
short face_square_pos =(75, 75, 83, 83);
void performantdelay(UINT8 numloops){
    UINT8 i;
    for(i = 0; i < numloops; i++){
        wait_vbl_done();
    }
}
void init_faceanim(){
/*this statement means that it is a enclosed program
that in this case, can be reused with the command
"init faceanim()"*/


set_sprite_tile(0,1);

set_sprite_tile(0,2);

set_sprite_tile(0,3);

set_sprite_tile(0,4);

set_sprite_tile(0,0);
}
void init_movement(){



    if(joypad() & J_DOWN){
         set_sprite_tile(1,14);
    set_sprite_tile(2,15);
    set_sprite_tile(3,16);
    set_sprite_tile(4,17);
    scroll_sprite(1,0,2);
    scroll_sprite(2,0,2);
    scroll_sprite(3,0,2);
    scroll_sprite(4,0,2);
     set_sprite_tile(1,10);
    set_sprite_tile(2,11);
    set_sprite_tile(3,12);
    set_sprite_tile(4,13);
    scroll_sprite(1,0,2);
    scroll_sprite(2,0,2);
    scroll_sprite(3,0,2);
    scroll_sprite(4,0,2);

    }
else;
    {
          if(joypad() & J_RIGHT){
    set_sprite_tile(1,22);
    set_sprite_tile(2,23);
    set_sprite_tile(3,24);
    set_sprite_tile(4,25);
    scroll_sprite(1,2,0);
    scroll_sprite(2,2,0);
    scroll_sprite(3,2,0);
    scroll_sprite(4,2,0);
delay(90);
     set_sprite_tile(1,18);
    set_sprite_tile(2,19);
    set_sprite_tile(3,20);
    set_sprite_tile(4,21);
    scroll_sprite(1,2,0);
    scroll_sprite(2,2,0);
    scroll_sprite(3,2,0);
    scroll_sprite(4,2,0);
    delay(90);
    }
    }
    else;
    {
          if(joypad() & J_UP){

    set_sprite_tile(1,30);
    set_sprite_tile(2,31);
    set_sprite_tile(3,32);
    set_sprite_tile(4,33);
    scroll_sprite(1,0,-2);
    scroll_sprite(2,0,-2);
    scroll_sprite(3,0,-2);
    scroll_sprite(4,0,-2);
    performantdelay(90);
     set_sprite_tile(1,26);
    set_sprite_tile(2,27);
    set_sprite_tile(3,28);
    set_sprite_tile(4,29);
    scroll_sprite(1,0,-2);
    scroll_sprite(2,0,-2);
    scroll_sprite(3,0,-2);
    scroll_sprite(4,0,-2);
        performantdelay(90);
    }
    }

    {
    if(joypad() & J_LEFT){

if(link_x <=70{

    scroll_sprite(1,0,0);
    scroll_sprite(2,0,0);
    scroll_sprite(3,0,0);
    scroll_sprite(4,0,0);
    performantdelay(90);
    scroll_sprite(1,0,0);
    scroll_sprite(2,0,0);
    scroll_sprite(3,0,0);
    scroll_sprite(4,0,0);
        performantdelay(90);
    }
if(link_x >=70){
link_x -=-4 ;

    set_sprite_tile(1,38);
    set_sprite_tile(2,39);
    set_sprite_tile(3,40);
    set_sprite_tile(4,41);
    scroll_sprite(1,-2,0);
    scroll_sprite(2,-2,0);
    scroll_sprite(3,-2,0);
    scroll_sprite(4,-2,0);
    performantdelay(90);
     set_sprite_tile(1,34);
    set_sprite_tile(2,35);
    set_sprite_tile(3,36);
    set_sprite_tile(4,37);
    scroll_sprite(1,-2,0);
    scroll_sprite(2,-2,0);
    scroll_sprite(3,-2,0);
    scroll_sprite(4,-2,0);
        performantdelay(90);
    }
    }
}
}
}
void main(){


set_sprite_data(0,5,face);
/*set sprite data sets the tiles of certain blocks of vram.
what that means is it allows you to set as well as reset blocks
from these. there are 720 of these in all.
also keep in mind gbdk still keeps them in numerical
order, for example 0A is still 10
OPEN your BGB emulator and right click anywhere on it,
look for the "other" option and open VRAM Viewer.
This will show a live display of currently opened sprites
as well as ones currently in use.(they will be highlighted)
this is especially useful when graphics are corrupted.*/

set_sprite_data(10,32,link);

    set_sprite_tile(0,0);
    set_sprite_data(5,1);
    set_sprite_data(6,1);
    set_sprite_data(7,1);

    set_sprite_tile(1,10);
        set_sprite_tile(2,11);
    set_sprite_tile(3,12);
    set_sprite_tile(4,13);


    move_sprite(0,75,75);
    move_sprite(5,75,83);
    move_sprite(6,83,75);
    move_sprite(7,83,83);




    move_sprite(1,91,75);
    move_sprite(2,99,75);
    move_sprite(3,91,83);
    move_sprite(4,99,83);

SPRITES_8x8;

SHOW_SPRITES;

while(1){


init_movement();




}

}
